## MiCORGB
#用APICloud实现的MiCO开发板的综合APP
	1、用户的注册登录
	2、EasyLink配网，mDNS发现设备，点击绑定
	3、显示设备列表
	4、修改设备名称和删除设备
	5、控制设备界面，温度超过29后显示红色，20-29绿色，低于20为黄色
	6、Add SSH key
